# ============================================================
# interfaz.py — Interfaz gráfica (GUI) de ChefCostos
# Frontend: Tkinter + Pillow
# Proyecto: Reto 2 - Gastronomía "Chef-Costos"
# ============================================================

import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk

# ── Rutas ─────────────────────────────────────────────────
FRONTEND_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR     = os.path.dirname(FRONTEND_DIR)
BACKEND_DIR  = os.path.join(BASE_DIR, "Backend")
DB_PATH      = os.path.join(BACKEND_DIR, "chef_costos.db")
LOGO_PATH    = os.path.join(FRONTEND_DIR, "imagenes", "logo.png")

# Agrega el Backend al path para importar los módulos
sys.path.insert(0, BACKEND_DIR)

from ingredientes import GestorIngredientes
from platos       import GestorPlatos
from recetas      import GestorRecetas
from alertas      import GestorAlertas
from datos        import CATEGORIAS_PLATOS, UMBRAL_INFLACION

# ── Paleta de colores ──────────────────────────────────────
COLOR_BG       = "#1a1208"   # fondo oscuro cálido
COLOR_PANEL    = "#2b1f0e"   # panel secundario
COLOR_CARD     = "#3a2a14"   # tarjetas / frames internos
COLOR_GOLD     = "#d4a017"   # dorado principal
COLOR_GOLD2    = "#f0c040"   # dorado brillante (hover)
COLOR_CREAM    = "#f5e6c8"   # texto claro
COLOR_MUTED    = "#9a8870"   # texto secundario
COLOR_SUCCESS  = "#4caf50"
COLOR_DANGER   = "#e53935"
COLOR_WARNING  = "#ff8f00"
COLOR_ENTRY_BG = "#4a3520"
COLOR_ENTRY_FG = "#f5e6c8"

FONT_TITLE  = ("Georgia", 14, "bold")
FONT_LABEL  = ("Trebuchet MS", 10, "bold")
FONT_ENTRY  = ("Consolas", 10)
FONT_BUTTON = ("Trebuchet MS", 10, "bold")
FONT_TABLE  = ("Consolas", 9)
FONT_SMALL  = ("Trebuchet MS", 9)


# ════════════════════════════════════════════════════════════
#  VENTANA PRINCIPAL
# ════════════════════════════════════════════════════════════
class ChefCostosApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Chef-Costos — Control Gastronómico")
        self.geometry("1050x700")
        self.minsize(900, 600)
        self.configure(bg=COLOR_BG)

        # Gestores de datos
        self.gi = GestorIngredientes(DB_PATH)
        self.gp = GestorPlatos(DB_PATH)
        self.gr = GestorRecetas(DB_PATH)
        self.ga = GestorAlertas(DB_PATH)

        self._build_ui()
        self.show_tab("ingredientes")

    # ── UI principal ─────────────────────────────────────────
    def _build_ui(self):
        self._build_header()
        self._build_nav()
        self._build_content()
        self._build_status()

    def _build_header(self):
        header = tk.Frame(self, bg=COLOR_PANEL, height=90)
        header.pack(fill="x")
        header.pack_propagate(False)

        # Logo
        try:
            img = Image.open(LOGO_PATH)
            img = img.resize((280, 80), Image.LANCZOS)
            self._logo_img = ImageTk.PhotoImage(img)
            tk.Label(header, image=self._logo_img, bg=COLOR_PANEL).pack(side="left", padx=15, pady=5)
        except Exception as e:
            tk.Label(header, text="🍽 CHEF-COSTOS", font=("Georgia", 22, "bold"),
                     fg=COLOR_GOLD, bg=COLOR_PANEL).pack(side="left", padx=20, pady=20)

        # Título derecha
        right = tk.Frame(header, bg=COLOR_PANEL)
        right.pack(side="right", padx=20)
        tk.Label(right, text="Sistema de Control de Costos Gastronómicos",
                 font=("Trebuchet MS", 11), fg=COLOR_MUTED, bg=COLOR_PANEL).pack(anchor="e")
        tk.Label(right, text="Base de datos SQLite · Tkinter · Pillow",
                 font=("Trebuchet MS", 9), fg="#6a5840", bg=COLOR_PANEL).pack(anchor="e")

    def _build_nav(self):
        nav = tk.Frame(self, bg=COLOR_GOLD, height=4)
        nav.pack(fill="x")

        tabs_frame = tk.Frame(self, bg=COLOR_BG)
        tabs_frame.pack(fill="x", pady=(0, 0))

        self.nav_buttons = {}
        tabs = [
            ("ingredientes", "🥬  Ingredientes"),
            ("platos",       "🍽  Platos"),
            ("recetas",      "📋  Recetas"),
            ("alertas",      "🔔  Alertas"),
        ]
        for key, label in tabs:
            btn = tk.Button(
                tabs_frame, text=label, font=FONT_BUTTON,
                bg=COLOR_BG, fg=COLOR_MUTED,
                activebackground=COLOR_CARD, activeforeground=COLOR_GOLD,
                relief="flat", bd=0, padx=18, pady=8, cursor="hand2",
                command=lambda k=key: self.show_tab(k)
            )
            btn.pack(side="left")
            self.nav_buttons[key] = btn

        # Separador
        tk.Frame(self, bg=COLOR_CARD, height=1).pack(fill="x")

    def _build_content(self):
        self.content = tk.Frame(self, bg=COLOR_BG)
        self.content.pack(fill="both", expand=True, padx=10, pady=8)

        self.tabs = {
            "ingredientes": TabIngredientes(self.content, self),
            "platos":       TabPlatos(self.content, self),
            "recetas":      TabRecetas(self.content, self),
            "alertas":      TabAlertas(self.content, self),
        }

    def _build_status(self):
        bar = tk.Frame(self, bg=COLOR_PANEL, height=28)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)
        self.status_var = tk.StringVar(value=f"📂  Base de datos: {DB_PATH}")
        tk.Label(bar, textvariable=self.status_var, font=("Consolas", 9),
                 fg=COLOR_MUTED, bg=COLOR_PANEL, anchor="w").pack(side="left", padx=10)

    # ── Navegación ────────────────────────────────────────────
    def show_tab(self, key: str):
        for k, frame in self.tabs.items():
            frame.pack_forget()
        self.tabs[key].pack(fill="both", expand=True)
        self.tabs[key].refresh()

        for k, btn in self.nav_buttons.items():
            if k == key:
                btn.configure(fg=COLOR_GOLD, bg=COLOR_CARD)
            else:
                btn.configure(fg=COLOR_MUTED, bg=COLOR_BG)

    def set_status(self, msg: str):
        self.status_var.set(f"  {msg}")


# ════════════════════════════════════════════════════════════
#  HELPERS REUTILIZABLES
# ════════════════════════════════════════════════════════════
def make_label(parent, text, **kw):
    defaults = dict(font=FONT_LABEL, fg=COLOR_CREAM, bg=COLOR_CARD, anchor="w")
    defaults.update(kw)
    return tk.Label(parent, text=text, **defaults)

def make_entry(parent, textvariable=None, width=22):
    e = tk.Entry(parent, textvariable=textvariable, width=width,
                 font=FONT_ENTRY, bg=COLOR_ENTRY_BG, fg=COLOR_ENTRY_FG,
                 insertbackground=COLOR_GOLD, relief="flat",
                 highlightthickness=1, highlightbackground=COLOR_GOLD,
                 highlightcolor=COLOR_GOLD2)
    return e

def make_button(parent, text, command, color=COLOR_GOLD, fg=COLOR_BG):
    return tk.Button(parent, text=text, command=command,
                     font=FONT_BUTTON, bg=color, fg=fg,
                     activebackground=COLOR_GOLD2, activeforeground=COLOR_BG,
                     relief="flat", bd=0, padx=14, pady=6, cursor="hand2")

def make_table(parent, columns, col_widths=None):
    style = ttk.Style()
    style.theme_use("clam")
    style.configure("Chef.Treeview",
                    background=COLOR_PANEL, foreground=COLOR_CREAM,
                    rowheight=24, fieldbackground=COLOR_PANEL,
                    font=FONT_TABLE)
    style.configure("Chef.Treeview.Heading",
                    background=COLOR_CARD, foreground=COLOR_GOLD,
                    font=FONT_LABEL)
    style.map("Chef.Treeview", background=[("selected", COLOR_GOLD)],
              foreground=[("selected", COLOR_BG)])

    frame = tk.Frame(parent, bg=COLOR_BG)
    sb = tk.Scrollbar(frame, orient="vertical")
    tree = ttk.Treeview(frame, columns=columns, show="headings",
                        style="Chef.Treeview", yscrollcommand=sb.set)
    sb.config(command=tree.yview)
    sb.pack(side="right", fill="y")
    tree.pack(side="left", fill="both", expand=True)

    for i, col in enumerate(columns):
        w = col_widths[i] if col_widths else 120
        tree.heading(col, text=col)
        tree.column(col, width=w, minwidth=50, anchor="center")

    return frame, tree


# ════════════════════════════════════════════════════════════
#  TAB: INGREDIENTES
# ════════════════════════════════════════════════════════════
class TabIngredientes(tk.Frame):
    def __init__(self, parent, app: ChefCostosApp):
        super().__init__(parent, bg=COLOR_BG)
        self.app = app
        self.gi  = app.gi
        self.ga  = app.ga
        self._build()

    def _build(self):
        # ── Panel izquierdo: formulario ──
        left = tk.Frame(self, bg=COLOR_CARD, width=320)
        left.pack(side="left", fill="y", padx=(0, 6))
        left.pack_propagate(False)

        tk.Label(left, text="Registrar Ingrediente", font=FONT_TITLE,
                 fg=COLOR_GOLD, bg=COLOR_CARD).pack(pady=(15, 10))
        tk.Frame(left, bg=COLOR_GOLD, height=2).pack(fill="x", padx=15)

        form = tk.Frame(left, bg=COLOR_CARD)
        form.pack(padx=15, pady=10, fill="x")

        fields = [
            ("Nombre:", "nombre"),
            ("Unidad (kg/lt/unidad):", "unidad"),
            ("Precio histórico (COP):", "p_hist"),
            ("Precio mercado (COP):", "p_mdo"),
        ]
        self.vars = {}
        for label, key in fields:
            make_label(form, label).pack(anchor="w", pady=(8, 1))
            v = tk.StringVar()
            self.vars[key] = v
            make_entry(form, textvariable=v).pack(fill="x")

        # Botones
        btn_frame = tk.Frame(left, bg=COLOR_CARD)
        btn_frame.pack(pady=12, padx=15, fill="x")
        make_button(btn_frame, "✅  Registrar", self._registrar).pack(fill="x", pady=(0, 6))
        make_button(btn_frame, "🗑  Limpiar", self._limpiar,
                    color=COLOR_CARD, fg=COLOR_MUTED).pack(fill="x")

        # Actualizar precio
        tk.Frame(left, bg=COLOR_GOLD, height=1).pack(fill="x", padx=15, pady=(10, 0))
        tk.Label(left, text="Actualizar Precio de Mercado", font=FONT_LABEL,
                 fg=COLOR_GOLD, bg=COLOR_CARD).pack(pady=(8, 2), padx=15, anchor="w")

        upd = tk.Frame(left, bg=COLOR_CARD)
        upd.pack(padx=15, fill="x")
        make_label(upd, "ID Ingrediente:").pack(anchor="w", pady=(4, 1))
        self.v_upd_id = tk.StringVar()
        make_entry(upd, self.v_upd_id, width=10).pack(anchor="w")
        make_label(upd, "Nuevo precio (COP):").pack(anchor="w", pady=(6, 1))
        self.v_upd_precio = tk.StringVar()
        make_entry(upd, self.v_upd_precio).pack(fill="x")
        make_button(upd, "💰  Actualizar Precio", self._actualizar_precio,
                    color=COLOR_WARNING, fg="#fff").pack(fill="x", pady=8)

        # ── Panel derecho: tabla ──
        right = tk.Frame(self, bg=COLOR_BG)
        right.pack(side="left", fill="both", expand=True)

        tk.Label(right, text="Listado de Ingredientes", font=FONT_TITLE,
                 fg=COLOR_GOLD, bg=COLOR_BG).pack(anchor="w", pady=(10, 4), padx=5)

        cols = ["ID", "Nombre", "Unidad", "Precio Hist. $", "Precio Mdo. $", "Inflación %", "Alerta"]
        widths = [40, 140, 60, 120, 120, 90, 70]
        tbl_frame, self.tree = make_table(right, cols, widths)
        tbl_frame.pack(fill="both", expand=True, padx=5, pady=5)

        make_button(right, "🔄  Actualizar tabla", self.refresh,
                    color=COLOR_CARD, fg=COLOR_GOLD).pack(anchor="e", padx=5, pady=4)

    def _registrar(self):
        nombre = self.vars["nombre"].get().strip()
        unidad = self.vars["unidad"].get().strip()
        p_hist_str = self.vars["p_hist"].get().strip()
        p_mdo_str  = self.vars["p_mdo"].get().strip()

        # Validaciones con try-except
        if not nombre:
            messagebox.showerror("Error de validación", "El nombre del ingrediente es obligatorio.")
            return
        if not unidad:
            messagebox.showerror("Error de validación", "La unidad es obligatoria (kg, lt, unidad).")
            return
        try:
            p_hist = float(p_hist_str.replace(",", "."))
            if p_hist <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Error de validación", "El precio histórico debe ser un número positivo.\nEjemplo: 8500")
            return
        try:
            p_mdo = float(p_mdo_str.replace(",", "."))
            if p_mdo <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Error de validación", "El precio de mercado debe ser un número positivo.\nEjemplo: 10200")
            return

        try:
            new_id = self.gi.registrar(nombre, unidad, p_hist, p_mdo)
            inf = self.gi.calcular_inflacion(new_id)
            if inf.get("alerta"):
                self.ga.registrar(new_id, nombre, inf["inflacion_pct"], p_hist, p_mdo)
                messagebox.showwarning(
                    "⚠ Alerta de Inflación",
                    f"Ingrediente '{nombre}' registrado con ID {new_id}.\n\n"
                    f"⚠ ALERTA: Inflación del {inf['inflacion_pct']:.1f}% — supera el umbral del {UMBRAL_INFLACION*100:.0f}%.\n"
                    "Se generó una alerta automáticamente."
                )
            else:
                messagebox.showinfo(
                    "✅ Registro Exitoso",
                    f"Ingrediente '{nombre}' registrado con ID {new_id}.\n"
                    f"Inflación: {inf['inflacion_pct']:.1f}% — dentro del rango normal."
                )
            self._limpiar()
            self.refresh()
            self.app.set_status(f"✅ Ingrediente '{nombre}' registrado — ID {new_id}")
        except Exception as e:
            messagebox.showerror("Error al registrar", str(e))

    def _limpiar(self):
        for v in self.vars.values():
            v.set("")

    def _actualizar_precio(self):
        try:
            id_ing = int(self.v_upd_id.get().strip())
        except ValueError:
            messagebox.showerror("Error", "El ID debe ser un número entero.")
            return
        try:
            nuevo = float(self.v_upd_precio.get().strip().replace(",", "."))
            if nuevo <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "El nuevo precio debe ser un número positivo.")
            return

        try:
            if self.gi.actualizar_precio_mercado(id_ing, nuevo):
                messagebox.showinfo("✅ Actualizado", f"Precio de mercado actualizado para ID {id_ing}.")
                self.v_upd_id.set("")
                self.v_upd_precio.set("")
                self.refresh()
                self.app.set_status(f"💰 Precio actualizado — ID {id_ing}")
            else:
                messagebox.showerror("Error", f"No se encontró ingrediente con ID {id_ing}.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def refresh(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for ing in self.gi.obtener_todos():
            ph = ing["precio_historico"]
            pm = ing["precio_mercado"]
            inf = (pm - ph) / ph * 100 if ph else 0
            alerta = "⚠ SÍ" if inf > UMBRAL_INFLACION * 100 else "✅ No"
            tag = "alert" if inf > UMBRAL_INFLACION * 100 else ""
            self.tree.insert("", "end", values=(
                ing["id"], ing["nombre"], ing["unidad"],
                f"$ {ph:,.0f}", f"$ {pm:,.0f}",
                f"{inf:.1f}%", alerta
            ), tags=(tag,))
        self.tree.tag_configure("alert", foreground=COLOR_WARNING)


# ════════════════════════════════════════════════════════════
#  TAB: PLATOS
# ════════════════════════════════════════════════════════════
class TabPlatos(tk.Frame):
    def __init__(self, parent, app: ChefCostosApp):
        super().__init__(parent, bg=COLOR_BG)
        self.app = app
        self.gp  = app.gp
        self._build()

    def _build(self):
        left = tk.Frame(self, bg=COLOR_CARD, width=280)
        left.pack(side="left", fill="y", padx=(0, 6))
        left.pack_propagate(False)

        tk.Label(left, text="Registrar Plato", font=FONT_TITLE,
                 fg=COLOR_GOLD, bg=COLOR_CARD).pack(pady=(15, 10))
        tk.Frame(left, bg=COLOR_GOLD, height=2).pack(fill="x", padx=15)

        form = tk.Frame(left, bg=COLOR_CARD)
        form.pack(padx=15, pady=10, fill="x")

        make_label(form, "Nombre del plato:").pack(anchor="w", pady=(8, 1))
        self.v_nombre = tk.StringVar()
        make_entry(form, self.v_nombre).pack(fill="x")

        make_label(form, "Categoría:").pack(anchor="w", pady=(8, 1))
        self.v_cat = tk.StringVar()
        combo = ttk.Combobox(form, textvariable=self.v_cat,
                             values=CATEGORIAS_PLATOS, state="readonly",
                             font=FONT_ENTRY, width=20)
        combo.pack(fill="x")

        btn_frame = tk.Frame(left, bg=COLOR_CARD)
        btn_frame.pack(pady=12, padx=15, fill="x")
        make_button(btn_frame, "✅  Registrar Plato", self._registrar).pack(fill="x", pady=(0, 6))
        make_button(btn_frame, "🗑  Limpiar", self._limpiar,
                    color=COLOR_CARD, fg=COLOR_MUTED).pack(fill="x")

        # Costos
        tk.Frame(left, bg=COLOR_GOLD, height=1).pack(fill="x", padx=15, pady=(15, 0))
        tk.Label(left, text="Ver Costo de un Plato", font=FONT_LABEL,
                 fg=COLOR_GOLD, bg=COLOR_CARD).pack(pady=(8, 2), padx=15, anchor="w")
        costo_frame = tk.Frame(left, bg=COLOR_CARD)
        costo_frame.pack(padx=15, fill="x")
        make_label(costo_frame, "ID del plato:").pack(anchor="w", pady=(4, 1))
        self.v_id_costo = tk.StringVar()
        make_entry(costo_frame, self.v_id_costo, width=10).pack(anchor="w")
        make_button(costo_frame, "📊  Calcular Costo", self._calcular_costo,
                    color=COLOR_WARNING, fg="#fff").pack(fill="x", pady=8)

        # Panel derecho
        right = tk.Frame(self, bg=COLOR_BG)
        right.pack(side="left", fill="both", expand=True)
        tk.Label(right, text="Listado de Platos", font=FONT_TITLE,
                 fg=COLOR_GOLD, bg=COLOR_BG).pack(anchor="w", pady=(10, 4), padx=5)

        cols = ["ID", "Nombre", "Categoría", "Costo Total $", "Precio Venta $"]
        widths = [40, 200, 120, 130, 130]
        tbl_frame, self.tree = make_table(right, cols, widths)
        tbl_frame.pack(fill="both", expand=True, padx=5, pady=5)
        make_button(right, "🔄  Actualizar tabla", self.refresh,
                    color=COLOR_CARD, fg=COLOR_GOLD).pack(anchor="e", padx=5, pady=4)

    def _registrar(self):
        nombre = self.v_nombre.get().strip()
        cat    = self.v_cat.get().strip()

        if not nombre:
            messagebox.showerror("Error de validación", "El nombre del plato es obligatorio.")
            return
        if not cat:
            messagebox.showerror("Error de validación", "Debe seleccionar una categoría.")
            return

        try:
            new_id = self.gp.registrar(nombre, cat)
            messagebox.showinfo("✅ Registro Exitoso",
                                f"Plato '{nombre}' registrado exitosamente.\nID asignado: {new_id}")
            self._limpiar()
            self.refresh()
            self.app.set_status(f"✅ Plato '{nombre}' registrado — ID {new_id}")
        except Exception as e:
            messagebox.showerror("Error al registrar", str(e))

    def _limpiar(self):
        self.v_nombre.set("")
        self.v_cat.set("")

    def _calcular_costo(self):
        try:
            id_plato = int(self.v_id_costo.get().strip())
        except ValueError:
            messagebox.showerror("Error", "El ID debe ser un número entero.")
            return

        datos = self.gp.calcular_costo(id_plato)
        if not datos:
            messagebox.showerror("No encontrado",
                                 f"No se encontró el plato con ID {id_plato} o no tiene ingredientes en su receta.")
            return

        messagebox.showinfo(
            "📊 Costo del Plato",
            f"🍽  {datos['nombre']}  ({datos['categoria']})\n\n"
            f"Costo total de ingredientes : $ {datos['costo_total']:>10,.0f}\n"
            f"Margen de ganancia ({datos['margen_pct']:.0f}%)   : $ {datos['costo_total'] * datos['margen_pct']/100:>10,.0f}\n"
            f"─────────────────────────────────────\n"
            f"Precio de venta sugerido    : $ {datos['precio_venta']:>10,.0f}"
        )

    def refresh(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for p in self.gp.obtener_todos():
            datos = self.gp.calcular_costo(p["id"])
            costo = f"$ {datos['costo_total']:,.0f}" if datos else "Sin receta"
            venta = f"$ {datos['precio_venta']:,.0f}" if datos else "—"
            self.tree.insert("", "end", values=(p["id"], p["nombre"], p["categoria"], costo, venta))


# ════════════════════════════════════════════════════════════
#  TAB: RECETAS
# ════════════════════════════════════════════════════════════
class TabRecetas(tk.Frame):
    def __init__(self, parent, app: ChefCostosApp):
        super().__init__(parent, bg=COLOR_BG)
        self.app = app
        self.gr  = app.gr
        self._build()

    def _build(self):
        left = tk.Frame(self, bg=COLOR_CARD, width=280)
        left.pack(side="left", fill="y", padx=(0, 6))
        left.pack_propagate(False)

        tk.Label(left, text="Agregar a Receta", font=FONT_TITLE,
                 fg=COLOR_GOLD, bg=COLOR_CARD).pack(pady=(15, 10))
        tk.Frame(left, bg=COLOR_GOLD, height=2).pack(fill="x", padx=15)

        form = tk.Frame(left, bg=COLOR_CARD)
        form.pack(padx=15, pady=10, fill="x")

        fields = [("ID del Plato:", "id_plato"), ("ID del Ingrediente:", "id_ing"),
                  ("Cantidad (en su unidad):", "cantidad")]
        self.vars = {}
        for label, key in fields:
            make_label(form, label).pack(anchor="w", pady=(8, 1))
            v = tk.StringVar()
            self.vars[key] = v
            make_entry(form, v, width=14).pack(anchor="w")

        btn_frame = tk.Frame(left, bg=COLOR_CARD)
        btn_frame.pack(pady=12, padx=15, fill="x")
        make_button(btn_frame, "✅  Agregar Ingrediente", self._agregar).pack(fill="x", pady=(0, 6))
        make_button(btn_frame, "🗑  Limpiar", self._limpiar,
                    color=COLOR_CARD, fg=COLOR_MUTED).pack(fill="x")

        # Info
        tk.Frame(left, bg=COLOR_GOLD, height=1).pack(fill="x", padx=15, pady=(15, 5))
        tk.Label(left, text="💡 La cantidad se expresa en\nla unidad del ingrediente.\nEj: 0.25 = 250g si es kg",
                 font=FONT_SMALL, fg=COLOR_MUTED, bg=COLOR_CARD, justify="left").pack(padx=15, anchor="w")

        right = tk.Frame(self, bg=COLOR_BG)
        right.pack(side="left", fill="both", expand=True)
        tk.Label(right, text="Todas las Recetas", font=FONT_TITLE,
                 fg=COLOR_GOLD, bg=COLOR_BG).pack(anchor="w", pady=(10, 4), padx=5)

        cols = ["ID", "Plato", "Ingrediente", "Unidad", "Cantidad", "Costo Parcial $"]
        widths = [40, 180, 160, 60, 80, 130]
        tbl_frame, self.tree = make_table(right, cols, widths)
        tbl_frame.pack(fill="both", expand=True, padx=5, pady=5)
        make_button(right, "🔄  Actualizar tabla", self.refresh,
                    color=COLOR_CARD, fg=COLOR_GOLD).pack(anchor="e", padx=5, pady=4)

    def _agregar(self):
        try:
            id_plato = int(self.vars["id_plato"].get().strip())
        except ValueError:
            messagebox.showerror("Error", "El ID del plato debe ser un número entero.")
            return
        try:
            id_ing = int(self.vars["id_ing"].get().strip())
        except ValueError:
            messagebox.showerror("Error", "El ID del ingrediente debe ser un número entero.")
            return
        try:
            cantidad = float(self.vars["cantidad"].get().strip().replace(",", "."))
            if cantidad <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "La cantidad debe ser un número positivo.\nEjemplo: 0.25")
            return

        try:
            new_id = self.gr.agregar_ingrediente(id_plato, id_ing, cantidad)
            messagebox.showinfo("✅ Agregado", f"Ingrediente agregado a la receta.\nID de receta: {new_id}")
            self._limpiar()
            self.refresh()
            self.app.set_status(f"✅ Ingrediente agregado a receta del plato {id_plato}")
        except Exception as e:
            messagebox.showerror("Error al agregar", str(e))

    def _limpiar(self):
        for v in self.vars.values():
            v.set("")

    def refresh(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for r in self.gr.obtener_todas():
            self.tree.insert("", "end", values=(
                r["id"], r["plato"], r["ingrediente"], r["unidad"],
                f"{r['cantidad']:.3f}", f"$ {r['costo_parcial']:,.0f}"
            ))


# ════════════════════════════════════════════════════════════
#  TAB: ALERTAS
# ════════════════════════════════════════════════════════════
class TabAlertas(tk.Frame):
    def __init__(self, parent, app: ChefCostosApp):
        super().__init__(parent, bg=COLOR_BG)
        self.app = app
        self.ga  = app.ga
        self.gi  = app.gi
        self._build()

    def _build(self):
        left = tk.Frame(self, bg=COLOR_CARD, width=280)
        left.pack(side="left", fill="y", padx=(0, 6))
        left.pack_propagate(False)

        tk.Label(left, text="🔔 Alertas de Inflación", font=FONT_TITLE,
                 fg=COLOR_GOLD, bg=COLOR_CARD).pack(pady=(15, 10))
        tk.Frame(left, bg=COLOR_DANGER, height=2).pack(fill="x", padx=15)

        info = tk.Frame(left, bg=COLOR_CARD)
        info.pack(padx=15, pady=12, fill="x")
        tk.Label(info, text=f"Umbral de alerta: > {UMBRAL_INFLACION*100:.0f}%",
                 font=FONT_LABEL, fg=COLOR_WARNING, bg=COLOR_CARD).pack(anchor="w")
        tk.Label(info, text="Se genera automáticamente\ncuando el precio de mercado\nsupera al histórico en más\ndel umbral definido.",
                 font=FONT_SMALL, fg=COLOR_MUTED, bg=COLOR_CARD, justify="left").pack(anchor="w", pady=(6, 0))

        tk.Frame(left, bg=COLOR_GOLD, height=1).pack(fill="x", padx=15, pady=(15, 5))
        tk.Label(left, text="Generar alerta manual:", font=FONT_LABEL,
                 fg=COLOR_GOLD, bg=COLOR_CARD).pack(padx=15, anchor="w")
        make_button(left, "🔍  Detectar Ingredientes\n     con Alta Inflación",
                    self._detectar, color=COLOR_DANGER, fg="#fff").pack(padx=15, pady=8, fill="x")

        right = tk.Frame(self, bg=COLOR_BG)
        right.pack(side="left", fill="both", expand=True)
        tk.Label(right, text="Historial de Alertas", font=FONT_TITLE,
                 fg=COLOR_GOLD, bg=COLOR_BG).pack(anchor="w", pady=(10, 4), padx=5)

        cols = ["ID", "Ingrediente", "Inflación %", "Precio Hist. $", "Precio Mdo. $", "Fecha"]
        widths = [40, 160, 90, 120, 120, 150]
        tbl_frame, self.tree = make_table(right, cols, widths)
        tbl_frame.pack(fill="both", expand=True, padx=5, pady=5)
        make_button(right, "🔄  Actualizar tabla", self.refresh,
                    color=COLOR_CARD, fg=COLOR_GOLD).pack(anchor="e", padx=5, pady=4)

    def _detectar(self):
        alertas = self.gi.ingredientes_con_alerta()
        if not alertas:
            messagebox.showinfo("✅ Sin alertas",
                                "Ningún ingrediente supera el umbral de inflación del "
                                f"{UMBRAL_INFLACION*100:.0f}%.\nTodos los precios están bajo control.")
            return

        for ing in alertas:
            self.ga.registrar(ing["id"], ing["nombre"], ing["inflacion_pct"],
                              ing["precio_historico"], ing["precio_mercado"])

        nombres = "\n".join(
            f"  • {a['nombre']}: {a['inflacion_pct']:.1f}%"
            for a in alertas
        )
        messagebox.showwarning(
            "⚠ Alertas Generadas",
            f"Se detectaron {len(alertas)} ingrediente(s) con alta inflación:\n\n{nombres}\n\n"
            "Las alertas han sido registradas en el historial."
        )
        self.refresh()
        self.app.set_status(f"⚠ {len(alertas)} alerta(s) de inflación generadas")

    def refresh(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for a in self.ga.obtener_todas():
            self.tree.insert("", "end", values=(
                a["id"], a["nombre"], f"{a['inflacion_pct']:.1f}%",
                f"$ {a['precio_historico']:,.0f}", f"$ {a['precio_mercado']:,.0f}", a["fecha"]
            ), tags=("alert",))
        self.tree.tag_configure("alert", foreground=COLOR_WARNING)


# ════════════════════════════════════════════════════════════
#  ENTRY POINT (también llamado desde main.py)
# ════════════════════════════════════════════════════════════
def iniciar():
    app = ChefCostosApp()
    app.mainloop()

if __name__ == "__main__":
    iniciar()
