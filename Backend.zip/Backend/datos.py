# ============================================================
# datos.py — Datos iniciales para ChefCostos
# Proyecto: Reto 2 - Gastronomía "Chef-Costos"
# ============================================================

# Ingredientes con precio histórico y precio de mercado actual
INGREDIENTES_INICIALES = [
    {"nombre": "Pollo",          "unidad": "kg",  "precio_historico": 8500,  "precio_mercado": 10200},
    {"nombre": "Arroz",          "unidad": "kg",  "precio_historico": 2200,  "precio_mercado": 2800},
    {"nombre": "Papa",           "unidad": "kg",  "precio_historico": 1800,  "precio_mercado": 2600},
    {"nombre": "Cebolla",        "unidad": "kg",  "precio_historico": 1500,  "precio_mercado": 2100},
    {"nombre": "Tomate",         "unidad": "kg",  "precio_historico": 2000,  "precio_mercado": 3200},
    {"nombre": "Aceite",         "unidad": "lt",  "precio_historico": 7000,  "precio_mercado": 9500},
    {"nombre": "Sal",            "unidad": "kg",  "precio_historico": 800,   "precio_mercado": 950},
    {"nombre": "Cilantro",       "unidad": "kg",  "precio_historico": 3000,  "precio_mercado": 4500},
    {"nombre": "Carne de res",   "unidad": "kg",  "precio_historico": 22000, "precio_mercado": 28500},
    {"nombre": "Lomo de cerdo",  "unidad": "kg",  "precio_historico": 15000, "precio_mercado": 19800},
    {"nombre": "Leche",          "unidad": "lt",  "precio_historico": 2500,  "precio_mercado": 3100},
    {"nombre": "Queso",          "unidad": "kg",  "precio_historico": 18000, "precio_mercado": 24000},
]

# Platos del restaurante
PLATOS_INICIALES = [
    {"nombre": "Bandeja Paisa",      "categoria": "Plato fuerte"},
    {"nombre": "Ajiaco Bogotano",    "categoria": "Sopa"},
    {"nombre": "Lomo al Trapo",      "categoria": "Plato fuerte"},
    {"nombre": "Arroz con Pollo",    "categoria": "Plato fuerte"},
]

# Configuración del negocio
MARGEN_GANANCIA    = 0.35   # 35% sobre el costo del plato
UMBRAL_INFLACION   = 0.20   # 20% → genera alerta de inflación
CATEGORIAS_PLATOS  = ["Entrada", "Sopa", "Plato fuerte", "Postre", "Bebida"]
