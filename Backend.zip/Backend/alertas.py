# ============================================================
# alertas.py — Módulo de alertas de inflación y reportes
# Proyecto: Reto 2 - Gastronomía "Chef-Costos"
# ============================================================

import sqlite3
from datetime import datetime
from datos import UMBRAL_INFLACION


class GestorAlertas:
    """Registra y consulta alertas de inflación por ingrediente."""

    def __init__(self, db_path: str):
        self.db_path = db_path

    def _conectar(self):
        return sqlite3.connect(self.db_path)

    # ── CRUD ──────────────────────────────────────────────────
    def registrar(self, id_ingrediente: int, nombre: str, inflacion_pct: float,
                  precio_historico: float, precio_mercado: float) -> int:
        fecha = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._conectar() as con:
            cur = con.execute(
                """INSERT INTO alertas
                   (id_ingrediente, nombre, inflacion_pct, precio_historico, precio_mercado, fecha)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (id_ingrediente, nombre, inflacion_pct, precio_historico, precio_mercado, fecha),
            )
        return cur.lastrowid

    def obtener_todas(self) -> list[dict]:
        with self._conectar() as con:
            cur = con.execute(
                "SELECT * FROM alertas ORDER BY fecha DESC"
            )
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchall()]

    def eliminar(self, id_alerta: int) -> bool:
        with self._conectar() as con:
            cur = con.execute("DELETE FROM alertas WHERE id=?", (id_alerta,))
        return cur.rowcount > 0

    # ── Reporte ───────────────────────────────────────────────
    def reporte_inflacion(self, ingredientes_alerta: list[dict]) -> None:
        """Imprime reporte visual de ingredientes con alta inflación."""
        print("\n" + "═" * 60)
        print(f"  🔥  REPORTE DE INFLACIÓN — {datetime.now():%Y-%m-%d}")
        print(f"  Umbral de alerta: >{UMBRAL_INFLACION*100:.0f}%")
        print("═" * 60)
        if not ingredientes_alerta:
            print("  ✅  Ningún ingrediente supera el umbral de inflación.\n")
            return
        for ing in ingredientes_alerta:
            print(f"  ⚠  {ing['nombre']:<20} inflación: {ing['inflacion_pct']:>6.1f}%"
                  f"  |  Hist: $ {ing['precio_historico']:,.0f}"
                  f"  →  Mdo: $ {ing['precio_mercado']:,.0f}")
        print("═" * 60 + "\n")
