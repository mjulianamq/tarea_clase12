# ============================================================
# platos.py — Módulo de gestión de platos del restaurante
# Proyecto: Reto 2 - Gastronomía "Chef-Costos"
# ============================================================

import sqlite3
from datos import CATEGORIAS_PLATOS, MARGEN_GANANCIA


class GestorPlatos:
    """CRUD de platos y cálculo de costo y precio de venta sugerido."""

    def __init__(self, db_path: str):
        self.db_path = db_path

    def _conectar(self):
        return sqlite3.connect(self.db_path)

    # ── CRUD ──────────────────────────────────────────────────
    def registrar(self, nombre: str, categoria: str) -> int:
        """Inserta un plato y retorna su ID."""
        if categoria not in CATEGORIAS_PLATOS:
            raise ValueError(f"Categoría inválida. Opciones: {CATEGORIAS_PLATOS}")
        with self._conectar() as con:
            cur = con.execute(
                "INSERT INTO platos (nombre, categoria) VALUES (?, ?)",
                (nombre.strip().title(), categoria),
            )
        return cur.lastrowid

    def obtener_todos(self) -> list[dict]:
        with self._conectar() as con:
            cur = con.execute(
                "SELECT id, nombre, categoria FROM platos ORDER BY categoria, nombre"
            )
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchall()]

    def actualizar(self, id_plato: int, nombre: str, categoria: str) -> bool:
        if categoria not in CATEGORIAS_PLATOS:
            raise ValueError(f"Categoría inválida. Opciones: {CATEGORIAS_PLATOS}")
        with self._conectar() as con:
            cur = con.execute(
                "UPDATE platos SET nombre=?, categoria=? WHERE id=?",
                (nombre.strip().title(), categoria, id_plato),
            )
        return cur.rowcount > 0

    def eliminar(self, id_plato: int) -> bool:
        with self._conectar() as con:
            cur = con.execute("DELETE FROM platos WHERE id=?", (id_plato,))
        return cur.rowcount > 0

    # ── Análisis ──────────────────────────────────────────────
    def calcular_costo(self, id_plato: int) -> dict:
        """Suma el costo de todos los ingredientes del plato."""
        with self._conectar() as con:
            cur = con.execute(
                """SELECT p.nombre, p.categoria,
                          SUM(r.cantidad * i.precio_mercado) as costo_total
                   FROM platos p
                   JOIN recetas r ON r.id_plato = p.id
                   JOIN ingredientes i ON i.id = r.id_ingrediente
                   WHERE p.id = ?
                   GROUP BY p.id""",
                (id_plato,),
            )
            row = cur.fetchone()
        if not row:
            return {}
        costo = row[2] or 0
        precio_venta = costo * (1 + MARGEN_GANANCIA)
        return {
            "nombre":        row[0],
            "categoria":     row[1],
            "costo_total":   round(costo, 2),
            "margen_pct":    MARGEN_GANANCIA * 100,
            "precio_venta":  round(precio_venta, 2),
        }

    def resumen_costos(self) -> list[dict]:
        """Costo y precio sugerido de todos los platos."""
        platos = self.obtener_todos()
        resultado = []
        for p in platos:
            datos = self.calcular_costo(p["id"])
            if datos:
                resultado.append(datos)
        return resultado
