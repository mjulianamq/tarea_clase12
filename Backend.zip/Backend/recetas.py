# ============================================================
# recetas.py — Módulo de gestión de recetas (relación plato-ingrediente)
# Proyecto: Reto 2 - Gastronomía "Chef-Costos"
# ============================================================

import sqlite3


class GestorRecetas:
    """CRUD de recetas: qué ingredientes y en qué cantidad usa cada plato."""

    def __init__(self, db_path: str):
        self.db_path = db_path

    def _conectar(self):
        return sqlite3.connect(self.db_path)

    # ── CRUD ──────────────────────────────────────────────────
    def agregar_ingrediente(self, id_plato: int, id_ingrediente: int, cantidad: float) -> int:
        """Agrega un ingrediente a la receta de un plato."""
        if cantidad <= 0:
            raise ValueError("La cantidad debe ser mayor a cero.")
        try:
            with self._conectar() as con:
                cur = con.execute(
                    """INSERT INTO recetas (id_plato, id_ingrediente, cantidad)
                       VALUES (?, ?, ?)""",
                    (id_plato, id_ingrediente, cantidad),
                )
            return cur.lastrowid
        except Exception as e:
            raise ValueError(f"Error al agregar ingrediente: {e}")

    def obtener_receta(self, id_plato: int) -> list[dict]:
        """Retorna todos los ingredientes de un plato con su costo parcial."""
        with self._conectar() as con:
            cur = con.execute(
                """SELECT r.id, i.nombre, i.unidad, r.cantidad,
                          i.precio_mercado,
                          r.cantidad * i.precio_mercado as costo_parcial
                   FROM recetas r
                   JOIN ingredientes i ON i.id = r.id_ingrediente
                   WHERE r.id_plato = ?
                   ORDER BY i.nombre""",
                (id_plato,),
            )
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchall()]

    def obtener_todas(self) -> list[dict]:
        """Retorna todas las recetas con nombre de plato e ingrediente."""
        with self._conectar() as con:
            cur = con.execute(
                """SELECT r.id, p.nombre as plato, i.nombre as ingrediente,
                          i.unidad, r.cantidad,
                          r.cantidad * i.precio_mercado as costo_parcial
                   FROM recetas r
                   JOIN platos p ON p.id = r.id_plato
                   JOIN ingredientes i ON i.id = r.id_ingrediente
                   ORDER BY p.nombre, i.nombre"""
            )
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchall()]

    def actualizar_cantidad(self, id_receta: int, nueva_cantidad: float) -> bool:
        if nueva_cantidad <= 0:
            raise ValueError("La cantidad debe ser mayor a cero.")
        with self._conectar() as con:
            cur = con.execute(
                "UPDATE recetas SET cantidad=? WHERE id=?",
                (nueva_cantidad, id_receta),
            )
        return cur.rowcount > 0

    def eliminar(self, id_receta: int) -> bool:
        with self._conectar() as con:
            cur = con.execute("DELETE FROM recetas WHERE id=?", (id_receta,))
        return cur.rowcount > 0
