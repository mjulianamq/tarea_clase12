# ============================================================
# ingredientes.py — Módulo de gestión de ingredientes
# Proyecto: Reto 2 - Gastronomía "Chef-Costos"
# ============================================================

import sqlite3
from datos import UMBRAL_INFLACION


class GestorIngredientes:
    """CRUD de ingredientes y cálculo de inflación por ingrediente."""

    def __init__(self, db_path: str):
        self.db_path = db_path

    def _conectar(self):
        return sqlite3.connect(self.db_path)

    # ── CRUD ──────────────────────────────────────────────────
    def registrar(self, nombre: str, unidad: str, precio_historico: float, precio_mercado: float) -> int:
        """Inserta un ingrediente y retorna su ID."""
        if precio_historico <= 0 or precio_mercado <= 0:
            raise ValueError("Los precios deben ser mayores a cero.")
        with self._conectar() as con:
            cur = con.execute(
                """INSERT INTO ingredientes (nombre, unidad, precio_historico, precio_mercado)
                   VALUES (?, ?, ?, ?)""",
                (nombre.strip().title(), unidad.strip(), precio_historico, precio_mercado),
            )
        return cur.lastrowid

    def obtener_todos(self) -> list[dict]:
        with self._conectar() as con:
            cur = con.execute(
                "SELECT id, nombre, unidad, precio_historico, precio_mercado FROM ingredientes ORDER BY nombre"
            )
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchall()]

    def obtener_por_id(self, id_ing: int) -> dict:
        with self._conectar() as con:
            cur = con.execute(
                "SELECT id, nombre, unidad, precio_historico, precio_mercado FROM ingredientes WHERE id=?",
                (id_ing,),
            )
            row = cur.fetchone()
            if not row:
                return {}
            cols = [d[0] for d in cur.description]
            return dict(zip(cols, row))

    def actualizar_precio_mercado(self, id_ing: int, nuevo_precio: float) -> bool:
        if nuevo_precio <= 0:
            raise ValueError("El precio debe ser mayor a cero.")
        with self._conectar() as con:
            cur = con.execute(
                "UPDATE ingredientes SET precio_mercado=? WHERE id=?",
                (nuevo_precio, id_ing),
            )
        return cur.rowcount > 0

    def eliminar(self, id_ing: int) -> bool:
        with self._conectar() as con:
            cur = con.execute("DELETE FROM ingredientes WHERE id=?", (id_ing,))
        return cur.rowcount > 0

    # ── Análisis ──────────────────────────────────────────────
    def calcular_inflacion(self, id_ing: int) -> dict:
        """Calcula el % de inflación y genera alerta si supera el umbral."""
        ing = self.obtener_por_id(id_ing)
        if not ing:
            return {}
        ph = ing["precio_historico"]
        pm = ing["precio_mercado"]
        inflacion = (pm - ph) / ph if ph else 0
        alerta = inflacion > UMBRAL_INFLACION
        return {
            "nombre":           ing["nombre"],
            "precio_historico": ph,
            "precio_mercado":   pm,
            "inflacion_pct":    round(inflacion * 100, 2),
            "alerta":           alerta,
        }

    def ingredientes_con_alerta(self) -> list[dict]:
        """Retorna todos los ingredientes que superan el umbral de inflación."""
        todos = self.obtener_todos()
        resultado = []
        for ing in todos:
            ph = ing["precio_historico"]
            pm = ing["precio_mercado"]
            inflacion = (pm - ph) / ph if ph else 0
            if inflacion > UMBRAL_INFLACION:
                resultado.append({
                    **ing,
                    "inflacion_pct": round(inflacion * 100, 2),
                })
        return resultado
